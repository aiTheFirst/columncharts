D3.js is a powerful JavaScript library for real time manipulation of data-driven documents. 

Combining JS, HTML, SVG and CSS, D3 makes is possible to create beautiful visualizations, driven by data, that the end consumer can interact with.

Here is what the final product looks like: http://ilukwe.com/d3tutorial/columns.html

See the tutorial here: http://bit.ly/d3tut